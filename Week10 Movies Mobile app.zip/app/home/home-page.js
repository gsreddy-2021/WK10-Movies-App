let observableArray = require("data/observable-array");
let observableModule = require("data/observable");

exports.pageLoaded = async function (args) {
  let page = args.object
  let pageData = new observableModule.Observable();

  // ⬇️ ⬇️ ⬇️ YOUR CODE BEGINS HERE ⬇️ ⬇️ ⬇️

  // 👇 uncomment and replace yourVariable
  // Step 2: uncomment the ObservableArray line of code and replace yourVariable.
  let moviesData = new observableArray.ObservableArray([])

  // Step 3: fetch the movies data from https://api.themoviedb.org/3/movie/now_playing?api_key=${apiKey}&language=en-US
  //         (replace with an api key).
  let apiKey = 'ebcd0c8bd7f9634f9dd933c786e737bb'
  let url = `https://api.themoviedb.org/3/movie/now_playing?api_key=${apiKey}&language=en-US`
  let response = await fetch(url)
  let json = await response.json()
  let results = json.results

  // Step 4: loop through the movie data; for each movie, build a javascript object with a title and imgUrl;
  //         the movie data's poster_path is only the end of the poster image's url - the beginning of the url is
  //         https://image.tmdb.org/t/p/w500; combine both as the full imgUrl. 
  //         add the new javascript object to the ObservableArray using.push()
  for (let i = 0; i < results.length; i++) {
    // a variable for each movie object
    let movie = results[i]

    let posterUrl = `https://image.tmdb.org/t/p/w500${movie.poster_path}`
    let title = movie.title
    let movieObject = {
      title: title,
      posterUrl: posterUrl
    }
    moviesData.push(movieObject)
  }

  // Step 5: uncomment the pageData.set() line of code and replace with your ObservableArray variable.

  // 👇 uncomment and replace with your variable name
  pageData.set('movies', moviesData)

  // ⬆️ ⬆️ ⬆️ YOUR CODE ENDS HERE ⬆️ ⬆️ ⬆️

  page.bindingContext = pageData
}